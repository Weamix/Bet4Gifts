#include <stdio.h>
#include <stdlib.h>

/****************************************************************/
/* Auteur:VITSE MAXIME                                          */
/* Groupe TP: A                                                 */
/* Date de cr�ation: 25/09/2018                                 */
/* Version 0.1 du 25/09/2018                                    */
/* Le but de ce programme est de d�terminer le plus grand de 6 entiers  */

int main()
{
    int a,b,c,d,e,f;
    int max;
    printf("\n Entrez premiere entier:");
    scanf("%d", &a);
    printf("\n Entrez deuxieme entier:");
    scanf("%d", &b);
    printf("\n Entrez troisieme entier:");
    scanf("%d", &c);
    printf("\n Entrez quatrieme entier:");
    scanf("%d", &d);
    printf("\n Entrez cinquieme entier:");
    scanf("%d", &e);
    printf("\n Entrez sixieme entier:");
    scanf("%d", &f);
    max=a; /** on d�finit une valeur maximum **/


    if(b>max){ /** si b est plus grand que la valeur maximum d�finit, alors cette valeur devient le maximum **/
        max=b;
    }

    if(c>max){
        max=c;
    }

    if(d>max){
        max=d;
    }

    if(e>max){
        max=e;
    }

    if(f>max){
        max=f;
    }


    printf("\n Le plus grand des 6 entiers est:");
    printf("%d",max);
    return 0;
}
