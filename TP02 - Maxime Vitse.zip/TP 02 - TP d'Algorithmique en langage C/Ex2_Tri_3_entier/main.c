#include <stdio.h>
#include <stdlib.h>

/****************************************************************/
/* Auteur:VITSE MAXIME                                          */
/* Groupe TP: A                                                 */
/* Date de cr�ation: 17/09/2018                                 */
/* Version 0.3 du 28/09/2018                                    */
/* Le but de ce programme est de trier 3 nombres entiers dans l'ordre croissant */


int main()
{

    int x,y,z,t;
    printf("\n Indiquez la premiere valeur quelconque:");
    scanf("%d", &x);
    printf("\n Indiquez la deuxieme valeur quelconque:");
    scanf("%d", &y);
    printf("\n Indiquez la troisieme valeur quelconque:");
    scanf("%d", &z);

    if (x>y){
        t=x; /** pour permettre la permutation, on stocke la valeur dans une variable "temporaire" **/
        x=y;
        y=t;
            }

    if (y>z){
        t=y;
        y=z;
        z=t;
            }

    if (x>y){
        t=y;
        x=y;
        y=t;
            }

     printf("%d > %d > %d ",x,y,z);
    return 0;
    }


