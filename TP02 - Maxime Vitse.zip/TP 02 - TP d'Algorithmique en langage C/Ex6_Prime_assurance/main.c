#include <stdio.h>
#include <stdlib.h>


/****************************************************************/
/* Auteur:VITSE MAXIME                                          */
/* Groupe TP: A                                                 */
/* Date de cr�ation: 25/09/2018                                 */
/* Version 0.3 du 30/09/2018                                    */
/* Le but de ce programme est de calculer la prime finale du contrat en fonction:
d'une prime de base, de l'�ge du conducteur et du nombre d'ann�es d'obtention de son permis */

int main()
{
    int age,annees_permis,prime_base;
    printf("Entrez la prime de base:");
    scanf("%d",&prime_base);
    printf("Entrez l'age du conducteur:");
    scanf("%d",&age);
    printf("Entrez le nombre d'annees d'obtention de votre permis :");
    scanf("%d",&annees_permis);

    /** si le permis a �t� obtenu il y a moins de 3 ans**/

   if ((annees_permis<3) && (age<30)){ /** moins de 3 ans de permis ET moins de 30 ans **/
        printf("%.0lf",prime_base*2.60);
    }

    else if ((annees_permis<3) && (age>=30 && age<=45)){ /** moins de 3 ans de permis ET entre 30 ans et moins de 45 ans **/
        printf("%.0lf",prime_base*1.30);
        }
    else if ((annees_permis<3) && (age>45)) { /** moins de 3 ans de permis ET plus de 45 ans**/
        printf("%.0lf",prime_base*1.20);
        }

    /** si le permis a �t� obtenu de 3 � moins de 5ans**/

    if ((annees_permis>=3 && annees_permis<5) && (age<30)){ /** de 3 � moins de 5 ans de permis ET moins de 30 ans **/
        printf("%.0lf",prime_base*1.50);
    }

    else if ((annees_permis>=3 && annees_permis<5) && (age>=30 && age<=45)){ /** de 3 � moins de 5 ans de permis ET entre 30 ans et moins de 45 ans **/
        printf("%.0lf",prime_base*1.10);
        }
    else if ((annees_permis>=3 && annees_permis<5) && (age>45)) { /** de 3 � moins de 5 ans de permis ET plus de 45 ans **/
        printf("%.0lf",prime_base*1.00);
        }

    /** si le permis a �t� obtenu il y a plus de 5 ans **/

    if ((annees_permis>5) && (age<30)){ /** plus de 5 ans de permis ET moins de 30 ans **/
        printf("%.0lf",prime_base*0.90);
    }

    else if ((annees_permis>5) && (age>=30 && age<=45)){ /** plus de 5 ans de permis ET entre 30 ans et moins de 45 ans **/
        printf("%.0lf",prime_base*0.80);
        }

    else if ((annees_permis>5) && (age>45)) { /** 5 ans et plus de permis ET plus de 45 ans **/
        printf("%.0lf",prime_base*0.50);
        }

    return 0;
}
