#include <stdio.h>
#include <stdlib.h>

/****************************************************************/
/* Auteur:VITSE MAXIME                                          */
/* Groupe TP: A                                                 */
/* Date de cr�ation: 30/09/2018                                 */
/* Version 0.3 du 30/09/2018                                    */
/* Le but de ce programme est de faire une petite calculatrice disposant des 4 op�rations de base (+ - * /).
Certaines erreurs (division par 0, mauvais op�rateur) sont d�tect�es et signal�es par un message.  */

int main()
{
    double donnee1, donnee2;
    char operateur;
    printf("?");
    scanf("%lf %c %lf", &donnee1, &operateur, &donnee2);

    switch (operateur) {
    case '+' : printf("=%lf",donnee1+donnee2) ; break ; /** le bloc des instructions (printf) � �x�cuter est d�cid� � partir de la valeur de l'expression en param�tre du switch**/
    case '-' : printf("=%lf",donnee1-donnee2) ; break ;
    case '*' : printf("=%lf",donnee1*donnee2) ; break ;
    case '/' :
        if(donnee2==0){
            printf("non divisible par 0");
        }

        else if (donnee2<0){
        printf("La deuxieme donnee doit etre strictement positive!");
        }

        else{
        printf("=%lf",donnee1/donnee2);
        }
        break ;

        default:printf("erreur dans la saisie de l'operateur");
    }

    return 0;
}
