#include <stdio.h>
#include <stdlib.h>

/****************************************************************/
/* Auteur:VITSE MAXIME                                          */
/* Groupe TP: A                                                 */
/* Date de cr�ation: 24/09/2018                                 */
/* Version 0.1 du 24/09/2018                                    */
/* Le but de ce programme est d'afficher les liquides gel�s pour une temp�rature indiquer par l'utilisateur  */

int main()
{
    int temperature;
    printf("\n Indiquez la temperature:");
    scanf("%d", &temperature);

    if (temperature>0) { /** on compare la valeur entr�e avec les crit�res pour chaque condition**/
        printf("Tout reste a l'etat liquide");
        } else {
        printf("\n L'eau gele!");
        }

    if (temperature<=-3){
        printf("\n L'eau sale gele!");
        }

    if (temperature<=-5){
        printf("\n Le fuel gele!");
        }

    if (temperature<=-13){
        printf("\n L'ordinaire gele!");
        }

    if (temperature<=-23){
        printf("\n Le super gele!");
        }

       return 0;
}
