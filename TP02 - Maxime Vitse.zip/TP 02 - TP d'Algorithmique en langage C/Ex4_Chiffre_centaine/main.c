#include <stdio.h>
#include <stdlib.h>

/****************************************************************/
/* Auteur:VITSE MAXIME                                          */
/* Groupe TP: A                                                 */
/* Date de cr�ation: 25/09/2018                                 */
/* Version 0.2 du 30/09/2018                                    */
/* Le but de ce programme est de d�terminer le chiffre de la centaine (exercice similaire au TP1 avec la d�composition de surface)  */

int main()
{
    int nb1,nb2,nb3,nb4,nb5;
    printf("Entrez un nombre superieur ou egal a 100:");
    scanf("%d", &nb1);
    if (nb1<100){
        printf("Le nombre n'est pas supperieur � 100");
    }
    if (nb1>100){
        nb2= nb1/100;
        nb3= nb1/1000;
        nb4= nb3*10;
        nb5= nb2-nb4;
        printf("La centaine est: %d", nb5);
    }
    return 0;
}
